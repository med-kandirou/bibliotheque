create function updatefunction() returns trigger
    language plpgsql
as
$$
BEGIN
    update exemplaire set statut='emprunté' where id=NEW.exemplaire_id;
    RETURN NULL;
END;
$$;

alter function updatefunction() owner to postgres;

